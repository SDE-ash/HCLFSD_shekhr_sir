import React from "react";
import "./App.css";
import "h8k-components";
import JobApplicationForm from "./components/JobApplicationForm";
import Preview from "./components/Preview";
import SuccessMessage from "./components/SuccessMessage";

const title = "Job Application Portal";

const App = () => {
  return (
    <div className="App pt-30 ma-auto" data-testid="app">
      <h8k-navbar header={title}></h8k-navbar>
      <JobApplicationForm />
      {/* <Preview />
      <SuccessMessage /> */}
    </div>
  );
};

export default App;
