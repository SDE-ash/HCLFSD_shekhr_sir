import React from "react";

const HiddenImageDiv = (props) => {
  return (
    <div className="empty" {...props}>
      Hidden Image
    </div>
  );
};

export default HiddenImageDiv;
