import * as images from "./images";
export const data = [
  {
    src: images.img1,
    visible: true,
    id: 1,
    alt: "Cras eget leo malesuada, ullamcorper",
  },
  {
    src: images.img2,
    visible: true,
    id: 2,
    alt: "Cras eget leo malesuada, ullamcorper",
  },
  {
    src: images.img3,
    visible: true,
    id: 3,
    alt: "Cras eget leo malesuada, ullamcorper",
  },
  {
    src: images.img4,
    visible: true,
    id: 4,
    alt: "Cras eget leo malesuada, ullamcorper",
  },
];
