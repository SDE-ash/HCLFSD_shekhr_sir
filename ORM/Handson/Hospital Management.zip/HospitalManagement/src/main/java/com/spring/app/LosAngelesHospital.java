package com.spring.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
//use appropriate annotation to make this class as component class
@Component
public class LosAngelesHospital implements HeadHospital {

    private Document losAngelesDocument;
    
    //use appropriate annotation 
    @Autowired
    public LosAngelesHospital(Document losAngelesDocument) {
        super();
        this.losAngelesDocument = losAngelesDocument;
    }

    // FILL THE CODE HERE
    @Override
    public void doDocumentVerification(){
        System.out.println("Document verification done using " + losAngelesDocument.getIdProof());
    }
    
    @Override
    public void provideTreatment(){
        System.out.println("Treatment is in progress for " + losAngelesDocument.getName() + 
        " with condition " +  losAngelesDocument.getCondition() + "at Los Angeles Hospital");
    }
}
