package com.spring.app;

//use appropriate annotation to make this class as component class 
public class NewYorkHospital {

    private Document newYorkDocument;
        
    //use appropriate annotation 
    public NewYorkHospital(Document newYorkDocument) {
        super();
        this.newYorkDocument = newYorkDocument;
    }

   // FILL THE CODE HERE
}
