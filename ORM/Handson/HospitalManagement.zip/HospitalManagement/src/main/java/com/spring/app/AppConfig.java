package com.spring.app;



//Use appropriate annotation 
public class AppConfig {
    
    //Use appropriate annotation 
    public Document newYorkDocument() {
        
        Document document = new Document();
        document.setName("Alice");
        document.setIdProof("Insurance");
        document.setCondition("Flu");
        
        return document;
    }
    
    //Use appropriate annotation 
    public Document losAngelesDocument() {
        
        Document document = new Document();
        document.setName("Bob");
        document.setIdProof("ID Card");
        document.setCondition("Sprain");
        
        return document;
    }
}
	 	  	      	 	    	      	    	      	 	
