package com.hcl.service;

import org.springframework.stereotype.Service;

import com.hcl.entity.Product;
import com.hcl.repository.ProductRepository;

import jakarta.transaction.Transactional;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Transactional
   //Optimistic locking only fails if two transactions use the same initial version
    public void updateWithOptimisticLock(Long id, int newQty) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        product.setQuantity(newQty);  // Modify
        productRepository.save(product);  // version will be checked here
    }

    @Transactional
    public void updateWithPessimisticLock(Long id, int newQty) {
    	 Product product = productRepository.findByIdWithPessimisticLock(id);
    	    
    	    try {
    	        Thread.sleep(10000); // Simulate 10s DB operation
    	    } catch (InterruptedException e) {
    	        e.printStackTrace();
    	    }

    	    product.setQuantity(newQty);
    	    productRepository.save(product);
    }
}
